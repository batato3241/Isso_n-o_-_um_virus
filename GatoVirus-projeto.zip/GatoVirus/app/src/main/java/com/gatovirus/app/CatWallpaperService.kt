package com.gatovirus.app

import android.service.wallpaper.WallpaperService
import android.media.MediaPlayer
import android.view.SurfaceHolder

class CatWallpaperService : WallpaperService() {
    override fun onCreateEngine(): Engine = CatEngine()

    inner class CatEngine : Engine() {
        private var player: MediaPlayer? = null
        private var visible = false

        override fun onSurfaceCreated(holder: SurfaceHolder) {
            super.onSurfaceCreated(holder)
            startVideo(holder)
        }

        override fun onVisibilityChanged(isVisible: Boolean) {
            visible = isVisible
            if (isVisible) {
                if (player == null) startVideo(surfaceHolder)
                else runCatching { player?.start() }
            } else {
                runCatching { player?.pause() }
            }
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            releasePlayer()
            super.onSurfaceDestroyed(holder)
        }

        override fun onDestroy() {
            releasePlayer()
            super.onDestroy()
        }

        private fun startVideo(holder: SurfaceHolder) {
            releasePlayer()
            if (!visible && !isPreview) return
            player = MediaPlayer.create(this@CatWallpaperService, R.raw.gato_dancando)?.apply {
                setDisplay(holder)
                isLooping = true
                setVolume(0f, 0f) // O vídeo fica totalmente sem som.
                setOnPreparedListener { mp -> if (visible || isPreview) mp.start() }
                runCatching { start() }
            }
        }

        private fun releasePlayer() {
            runCatching { player?.stop() }
            runCatching { player?.release() }
            player = null
        }
    }
}
