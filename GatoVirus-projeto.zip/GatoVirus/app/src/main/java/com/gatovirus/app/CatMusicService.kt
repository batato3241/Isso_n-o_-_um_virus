package com.gatovirus.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.media.MediaPlayer
import android.os.Build
import android.os.IBinder

class CatMusicService : Service() {
    companion object {
        const val ACTION_PLAY = "com.gatovirus.app.PLAY"
        const val ACTION_STOP = "com.gatovirus.app.STOP"
        private const val CHANNEL_ID = "cat_music"
        private const val NOTIFICATION_ID = 67
    }

    private var player: MediaPlayer? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopMusic()
            return START_NOT_STICKY
        }
        if (player?.isPlaying == true) return START_NOT_STICKY

        createChannel()
        startForeground(NOTIFICATION_ID, buildNotification())
        player = MediaPlayer.create(this, R.raw.musica_gatos)?.apply {
            setOnCompletionListener {
                stopMusic()
            }
            start()
        }
        if (player == null) stopMusic()
        return START_NOT_STICKY
    }

    private fun buildNotification(): Notification {
        val stopIntent = Intent(this, CatMusicService::class.java).apply { action = ACTION_STOP }
        val pending = PendingIntent.getService(this, 1, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL_ID) else Notification.Builder(this)
        return builder
            .setContentTitle("Gatovírus 🐱")
            .setContentText("A música dos gatinhos está tocando")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_media_pause, "Parar música", pending)
            .build()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(NotificationChannel(CHANNEL_ID, "Música dos gatinhos", NotificationManager.IMPORTANCE_LOW))
        }
    }

    private fun stopMusic() {
        runCatching { player?.stop() }
        runCatching { player?.release() }
        player = null
        if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE) else @Suppress("DEPRECATION") stopForeground(true)
        stopSelf()
    }

    override fun onDestroy() {
        runCatching { player?.release() }
        player = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
