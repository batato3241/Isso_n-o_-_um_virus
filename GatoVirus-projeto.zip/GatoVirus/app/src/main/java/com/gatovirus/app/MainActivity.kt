package com.gatovirus.app

import android.Manifest
import android.app.Activity
import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestNotificationPermissionIfNeeded()

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 36, 28, 36)
            setBackgroundColor(0xFFFFF4F8.toInt())
        }
        val title = TextView(this).apply {
            text = "🐱 GATOVÍRUS 🐱"
            textSize = 30f
            gravity = Gravity.CENTER
            setTextColor(0xFF9B426A.toInt())
        }
        val info = TextView(this).apply {
            text = "Seu celular pode ganhar um gatinho dançando na tela inicial e uma música fofinha.\n\nNada é alterado sem sua confirmação. A música toca uma vez e pode ser parada pela notificação."
            textSize = 17f
            gravity = Gravity.CENTER
            setTextColor(0xFF49343D.toInt())
            setPadding(0, 24, 0, 24)
        }
        val wallpaper = Button(this).apply {
            text = "COLOCAR GATINHO NA TELA INICIAL"
            setOnClickListener { chooseWallpaper() }
        }
        val music = Button(this).apply {
            text = "TOCAR A MÚSICA DE NOVO"
            setOnClickListener { startCatMusic() }
        }
        val restore = Button(this).apply {
            text = "ABRIR CONFIGURAÇÕES DE PAPEL DE PAREDE"
            setOnClickListener {
                runCatching { startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER)) }
                    .onFailure { Toast.makeText(this@MainActivity, "Abra Configurações > Papel de parede para restaurar.", Toast.LENGTH_LONG).show() }
            }
        }
        listOf(title, info, wallpaper, music, restore).forEach { view ->
            layout.addView(view, LinearLayout.LayoutParams(-1, if (view == title || view == info) -2 else -2).apply {
                bottomMargin = if (view is Button) 12 else 0
            })
        }
        setContentView(layout)
        // Ao abrir o app, começa uma reprodução nova se não houver outra tocando.
        startCatMusic()
    }

    private fun chooseWallpaper() {
        // O Android apresenta a tela oficial de prévia/confirmação. A pessoa escolhe somente a tela inicial.
        val intent = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER).apply {
            putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                ComponentName(this@MainActivity, CatWallpaperService::class.java))
        }
        runCatching { startActivity(intent) }
            .onSuccess { /* A música já começa ao abrir o app. */ }
            .onFailure { Toast.makeText(this, "Não foi possível abrir a seleção de papel de parede.", Toast.LENGTH_LONG).show() }
    }

    private fun startCatMusic() {
        val intent = Intent(this, CatMusicService::class.java).apply { action = CatMusicService.ACTION_PLAY }
        runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent) else startService(intent)
        }.onFailure { Toast.makeText(this, "O Android não permitiu iniciar a música. Tente tocar no botão novamente.", Toast.LENGTH_LONG).show() }
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 22)
        }
    }
}
